<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Twit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TwittController extends Controller
{
    public function createTwitt(Request $request)
    {
        $twit = Twit::create([
            'content' => $request->content,
            'user_id' => $request->user_id,
        ]);
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('public/twit_images');
            $twit->images()->create([
                'filename' => basename($imagePath),
            ]);
        }

        return response()->json(['message' => 'Twit created successfully', 'twit' => $twit], 201);
    }

    public function updateTwit(Request $request, $id)
    {
        $updatedTwit = Twit::where('id', $id)->first();
        $updatedTwit->update([
            'content' => $request->content,
            'user_id' => $request->user_id,
        ]);

        if ($request->hasFile('image')) {
            if ($updatedTwit->images()->exists()) {
                foreach ($updatedTwit->images as $image) {
                    Storage::delete('public/twit_images/' . $image->filename);
                    $image->delete();
                }
            }
            $imagePath = $request->file('image')->store('public/twit_images');
            $updatedTwit->images()->create([
                'filename' => basename($imagePath),
            ]);
        }

        return response()->json(['updatedTwit' => $updatedTwit]);
    }

    public function fetchTwitt()
    {
        $twitts = Twit::with(['user', 'images'])->latest()->get();
        $twitts->each(function ($twit) {
            $twit->images->each(function ($image) {
                $image->image_path = $image->image_path;
            });
        });

        return response()->json(['twitts' => $twitts]);
    }

    public function fetchTwittByUser($id)
    {
        $userTwit = Twit::where('user_id', $id)->get();
        return response()->json(['userTwit' => $userTwit]);
    }

    public function deleteTwit($id)
    {
        $twit = Twit::find($id);
        if ($twit) {
            $twit->delete();
            return response()->json(['message' => 'Twit deleted successfully'], 200);
        }
        return response()->json(['message' => 'Twit not found']);
    }

    public function viewTwitt(Request $request)
    {
        $search = $request->input('search');
        $sort = $request->input('sort', 'desc');
        $query = Twit::with(['user', 'images']);

        if (!empty($search)) {
            $query->whereHas('user', function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%')
                    ->orWhere('email', 'like', '%' . $search . '%');
            })
                ->orWhere('content', 'like', '%' . $search . '%');
        }
        $query->orderBy('created_at', $sort);

        $twitts = $query->paginate(3);

        // $twitts = $query->orderBy('created_at', $sort)->get();

        // $twitts = $query->get();

        // $twitts = Twit::with(['user', 'images'])->latest()->get();
        return view('twitts.index', compact('twitts'));
    }
}
