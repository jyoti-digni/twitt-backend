<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Hobby;
use App\Models\HobbyMultiImage;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function uploadForm()
    {
        $hobbies = Hobby::all();
        return view('upload_form', compact('hobbies'));
    }

    public function submitForm(Request $request)
    {

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filename = $image->store('multi_images', 'public');

                foreach ($request->hobbies as $hobby_id) {
                    HobbyMultiImage::create([
                        'name' => $request->name,
                        'filename' => $filename,
                        'hobby_id' => $hobby_id
                    ]);
                }
                // $multiImage = HobbyMultiImage::create([
                //     'name' => $request->name,
                //     'filename' => $filename
                // ]);

                // $multiImage->hobbies()->attach($request->hobby_id);
            }
        }

        return redirect()->route('multiupload')->with('message', 'Images stored successfully!');
    }
}
