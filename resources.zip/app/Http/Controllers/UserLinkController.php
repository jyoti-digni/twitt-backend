<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\UserLink;
use Illuminate\Http\Request;

class UserLinkController extends Controller
{
    public function createLink(Request $request)
    {
        $userlink = new UserLink();
        $userlink->description = $request->description;
        $userlink->link = $request->link;
        $userlink->user_id = $request->user_id;
        $userlink->save();
        return response()->json(['userlink' => $userlink], 201);
    }

    public function fetchUserLink()
    {
        $userLinks = UserLink::all();
        return response()->json(['userLinks' => $userLinks]);
    }

    public function updateUserLink(Request $request, $id)
    {
        $updatedLink = UserLink::where('id', $id)->first();
        if ($updatedLink) {
            $updatedLink->description = $request->description;
            $updatedLink->link = $request->link;
            $updatedLink->user_id = $request->user_id;
            $updatedLink->save();
        }
        return response()->json(['updatedLink' => $updatedLink], 201);
    }
    public function deleteUserLink($id)
    {
        $userLink = UserLink::find($id);
        if ($userLink) {
            $userLink->delete();
            return response()->json(['message' => 'User link deleted successfully'], 200);
        }
        return response()->json(['message' => 'User link not found']);
    }
}
