<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);
        $user = User::where('email', $request->email)->first();


        if (!$user) {
            return response()->json(['message' => 'User not found!'], 404);
        }
        if (Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Invalid password!'], 401);
        }
        $token = $user->createToken('token-name')->plainTextToken;
        return response()->json(['token' => $token, 'user' => $user], 200);
    }


    public function register(Request $request)
    {
        $user = new User();
        $user->name = $request->name;
        $user->username = $request->username;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);

        $user->save();
        return response()->json(['user' => $user], 201);
    }

    public function fetchUser()
    {
        $users = User::all();
        return response()->json(['users' => $users]);
    }

    public function authUserDetails()
    {
        $userDetails = Auth::user();
        return response()->json(['userDetails' => $userDetails]);
    }
}
