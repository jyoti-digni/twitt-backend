<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    use HasFactory;
    protected $fillable = ['filename'];

    public function imageable()
    {
        return $this->morphTo();
    }

    public function getImageUrlAttribute()
    {
        return url('storage/twit_images/' . $this->url);
    }

    public function getImagePathAttribute()
    {
        return url('storage/twit_images/' . $this->filename);
    }

   
}
