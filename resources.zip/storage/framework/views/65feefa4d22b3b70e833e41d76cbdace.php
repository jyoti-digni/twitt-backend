<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Twitt</title>
</head>

<body>

    <div class="container mx-auto py-12">
        <!-- Search Bar -->
        <form action="<?php echo e(route('twitt')); ?>" method="GET">


            <div class="flex justify-between items-center mb-6">
                <div class="relative">
                    <input type="text"
                        class="border border-gray-300 rounded-lg py-2 px-4 w-full pl-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Search...">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                </div>

                <!-- Sort Dropdown -->
                <div>
                    <select
                        class="border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="asc">Sort by: Ascending</option>
                        <option value="desc">Sort by: Descending</option>
                    </select>
                </div>
            </div>
        </form>
        <!-- Table -->
        <div class="overflow-x-auto p-6 my-6">
            <table class="min-w-full table-auto bg-white shadow-md rounded-lg">
                <thead class="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                    <tr>
                        <th class="py-3 px-6 text-left">Name</th>
                        <th class="py-3 px-6 text-left">Email</th>
                        <th class="py-3 px-6 text-left">Content</th>
                        <th class="py-3 px-6 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                    <?php $__currentLoopData = $twitts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twitt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo e($twitt->user->name); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo e($twitt->user->email); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo e($twitt->content); ?></td>
                            <td class="py-3 px-6 text-center">
                                <div class="flex item-center justify-center">
                                    <button class="w-4 mr-2 transform hover:text-blue-500 hover:scale-110">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>

                                    <button class="w-4 mr-2 transform hover:text-red-500 hover:scale-110">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4 flex justify-center">
            <button class="px-4 py-2 mx-1 text-white bg-blue-500 rounded-lg hover:bg-blue-700">Previous</button>
            <button class="px-4 py-2 mx-1 text-white bg-blue-500 rounded-lg hover:bg-blue-700">Next</button>
        </div>
    </div>

    <script></script>

</body>

</html>
<?php /**PATH D:\xampp-versions\xampp\htdocs\twit-backend\resources\views\twitts\index.blade.php ENDPATH**/ ?>