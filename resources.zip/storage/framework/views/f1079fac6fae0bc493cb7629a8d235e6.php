<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="upload-image" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>

        <input type="text" name="name" placeholder="Image set name">

        <select name="hobbies[]" multiple>
            <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($hobby->id); ?>"><?php echo e($hobby->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="file" name="images[]" multiple>

        <button type="submit">Submit</button>


    </form>

</body>

</html>
<?php /**PATH D:\xampp-versions\xampp\htdocs\twit-backend\resources\views\upload_form.blade.php ENDPATH**/ ?>