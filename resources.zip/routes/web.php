<?php

use App\Http\Controllers\TwittController;
use App\Http\Controllers\UploadController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


Route::get('multiupload', [UploadController::class, 'uploadForm'])->name('multiupload');


Route::post('upload-image', [UploadController::class, 'submitForm']);

Route::get('/twitt', [TwittController::class, 'viewTwitt'])->name('twitt');
