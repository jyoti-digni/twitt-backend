<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookmarkController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\TwittController;
use App\Http\Controllers\UserLinkController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::get('/fetch-users', [AuthController::class, 'fetchUser']);
Route::get('/auth-user-details', [AuthController::class, 'authUserDetails'])->middleware('auth:sanctum');


Route::post('/twitt-create', [TwittController::class, 'createTwitt']);
Route::get('/fetch-twitt', [TwittController::class, 'fetchTwitt']);
Route::get('/fetch-twit/{id}', [TwittController::class, 'fetchTwittByUser']);
Route::delete('/delete/twit/{id}', [TwittController::class, 'deleteTwit']);
Route::put('/update/twit/{id}', [TwittController::class, 'updateTwit']);

Route::post('/create/user-link', [UserLinkController::class, 'createLink']);
Route::get('/fetch-user-link', [UserLinkController::class, 'fetchUserLink']);
Route::put('/update/user-link/{id}', [UserLinkController::class, 'updateUserLink']);
Route::delete('/delete/user-link/{id}', [UserLinkController::class, 'deleteUserLink']);

Route::post('/add-like', [LikeController::class, 'addLike']);


Route::post('/add-bookmark', [BookmarkController::class, 'addBookmark']);
